# Pubblicare Gaia's Cakes online

Il sito è **statico** (solo HTML, CSS, JS e immagini): non serve un server né un database.
Puoi metterlo online **gratis** in pochi minuti. Sotto trovi 3 strade, dalla più facile.

Cartella da pubblicare: **tutta** `pasticceria-viola/` (contiene `index.html` + `assets/`).

---

## Opzione A — Netlify Drop (la più veloce, senza account tecnico)

1. Vai su **https://app.netlify.com/drop**
2. Trascina la cartella `pasticceria-viola` (o il file `gaias-cakes-sito.zip`) nella pagina.
3. In pochi secondi ottieni un link tipo `https://nome-a-caso.netlify.app` — già online, anche da 4G.
4. (Consigliato) Crea un account gratuito per non perdere il sito e poter aggiornare.
5. Per cambiare il nome: **Site settings → Change site name** (es. `gaias-cakes.netlify.app`).

> Per aggiornare il sito in futuro: ritrascini la cartella aggiornata.

---

## Opzione B — Cloudflare Pages (ottimo se vuoi il dominio .it)

1. Crea un account su **https://pages.cloudflare.com**
2. **Create a project → Direct Upload** e carica la cartella `pasticceria-viola`.
3. Ottieni un link `https://gaias-cakes.pages.dev`.
4. Per il dominio: vedi sotto.

---

## Opzione C — GitHub Pages (se usi già GitHub)

1. Crea un repository, carica il contenuto di `pasticceria-viola` nella radice.
2. **Settings → Pages → Deploy from a branch → main / (root)**.
3. Ottieni `https://tuo-utente.github.io/nome-repo/`.

---

## Collegare il dominio gaiascakes.it

1. **Compra il dominio** (es. su Netlify Domains, Cloudflare, Aruba, Namecheap ~10–15 €/anno).
2. Nel pannello dell'hosting scelto:
   - **Netlify:** Site settings → Domain management → Add custom domain → `gaiascakes.it`.
   - **Cloudflare Pages:** Custom domains → Set up a domain.
3. Segui le istruzioni per i **record DNS** (l'hosting te li mostra: di solito un record `A`/`CNAME`).
4. L'**HTTPS** (lucchetto) viene attivato in automatico e gratis.

---

## Prima di pubblicare: dati da aggiornare

Questi sono ancora **segnaposto** nel sito — sostituiscili con i tuoi dati reali
(sono ripetuti su più pagine, quindi vanno cambiati ovunque compaiono):

- **Telefono:** `02 5512 3456` → il tuo numero (compare in `tel:+390255123456`)
- **WhatsApp:** `340 123 4567` → il tuo (compare in `https://wa.me/393401234567`)
- **Email:** `ciao@gaiascakes.it`
- **P.IVA:** `01234567890` (nel footer di ogni pagina)
- **Social:** i link Instagram/Facebook puntano ai siti generici → metti i tuoi profili
- **Mappa e indirizzo:** verificati su `Piazza IV Novembre 30, Maerne` (controlla che la mappa
  in Contatti mostri il punto esatto)

Se vuoi, posso applicarli io in tutto il sito: mandami i valori corretti.

---

## Struttura del sito

```
pasticceria-viola/
├── index.html            (Home)
├── chi-siamo.html
├── prodotti.html         (menu con filtri)
├── galleria.html         (carosello collezioni)
├── recensioni.html
├── contatti.html         (form + mappa + orari)
├── ordini-speciali.html  (form preventivo)
└── assets/
    ├── css/style.css
    ├── js/main.js
    └── img/  (logo.svg, foto/, photos/)
```
